export class Cidade {
  nome: string;
}
