import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nova',
  templateUrl: './nova.page.html',
  styleUrls: ['./nova.page.scss'],
})
export class NovaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

validar(){
  /*if (senha != ) {
    alert("Senhas diferentes!");
  }
  else {
    ('redefinido com sucesso!');
  }*/
}
}
